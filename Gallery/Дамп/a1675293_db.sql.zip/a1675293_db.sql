-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 04, 2013 at 02:15 AM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a1675293_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `header` varchar(255) CHARACTER SET cp1251 NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` VALUES(1, 'Animals', 1, '0000-00-00 00:00:00');
INSERT INTO `category` VALUES(4, 'Peoples', 1, '0000-00-00 00:00:00');
INSERT INTO `category` VALUES(3, 'Cities', 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `photo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `desc` text CHARACTER SET cp1251 NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `photo` (`photo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `photo`
--

INSERT INTO `photo` VALUES(1, 1, '3ad2e74a062688701ab5c2fa27040942.jpg', '', 1, '2013-09-03 16:43:23');
INSERT INTO `photo` VALUES(2, 1, '8eabbe0503eed68acddf29d12c350ff0.jpg', '', 1, '2013-09-03 16:43:23');
INSERT INTO `photo` VALUES(3, 1, '279c72ba15c1e658baa89138b7bc44ba.jpg', '', 1, '2013-09-03 16:44:40');
INSERT INTO `photo` VALUES(4, 1, 'e94127f24d742725d512c759793d8945.jpg', '', 1, '2013-09-03 16:44:40');
INSERT INTO `photo` VALUES(5, 1, '3b7129701704ecf77b2a1b662af18dc2.jpg', '', 1, '2013-09-03 16:44:40');
INSERT INTO `photo` VALUES(6, 1, '9b09154d45481e9987578b0c716ddb88.jpg', '', 1, '2013-09-03 16:44:40');
INSERT INTO `photo` VALUES(7, 1, 'e4d27454fbc17a1381bd8e3cfee3ef5e.jpg', '', 1, '2013-09-03 16:47:34');
INSERT INTO `photo` VALUES(8, 4, '3b3a34920cc3792ecb9c4827259eec6f.jpg', '', 1, '2013-09-03 16:49:01');
